# Check_Tool_Cpp

Templates that AIDS in performing various checks



#### Check Function in Class

* Register

    ```c++
    REGISTERFUNCTIONFORCHECK(is_init)
    ```

* Check

    ```c++
    CHECKCLASSFUNCTION(T,is_init,bool)
    ```

    

