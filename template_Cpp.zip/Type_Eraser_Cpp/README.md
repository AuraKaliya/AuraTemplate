# Type_Eraser_Cpp

Use type erase for a second-level call template specialized for a function name.